PAL files
---------

This are the PAL PLD source and JED files for my custom IGS PGM Cave board.

I use ATF16V8B-15PU-ND (https://www.digikey.co.uk/short/pjvhzq), but any compatible 16V8 should work.

You need to program the .JED files, the PLD files are included for reference or modification. They can be opened in WinCUPL.

For U6 please use:
rg_u6.pld / PGM_RG_U6.jed 
This maps the address for the tile ROM into the space used by the EPROMs, and generates the OE lines for T1, T2 and the tile ROM on the motherboard.

For U5 you have three choices:
rg_u5_ddp.pld / PGM_RG_U5_DDP.jed
rg_u5_esp.pld / PGM_RG_U5_ESP.jed
rg_u5_qb.pld / PGM_RG_U5_QB.jed
rg_u5.pld / PGM_RG_U5.jed

rg_u5_ddp is pre-configured for DoDonPachi DaiOuJou by mapping the cart ROM behind the BIOS, rg_u5_esp is pre-configured for Ketsui and Espgaluda by 
replacing the BIOS with the cart ROM. Both support switching the low and high bank with JP2 (the middle one). The default is the first bank if no jumper 
is set/populated.

rg_u5_qb is a variant of rb_u5_esp: It is automatically configured for 4MB mode, and JP1 maps the 1st MB of the ROM to the motherboard or the cart. The 
default is to use the 1st MB from the cart. That way you can replace the BIOS with the one used on stand-alone PCBs.

rg_u5 supports flexible configuration with jumpers: JP1 selects between ESP and DDP mode (default is ESP mode), JP2 selects between first and second bank 
(default is first bank) and JP3 enables a "4MB" mode that maps the full address space of the ROM.
