import sys, hashlib, os, os.path, zipfile, argparse, glob, struct

bios = None

# rules to identify various input ROMs and which file to convert them into
rules = {
    # DoDonPachi DaiOuJou
    # ROM from Mame ddpdojblkbl romset, contains "WWW.ARCADEMODBIOS.COM" string at 0x100:
    "616500180768e79fd13cc786de3b357062076c6f866de13add309a0c7f8b3cde": ( True, False, True, ((0x00000, 0x400000, "ddp3_rg/ddp3_p1_amb.bin"),)),
    # Patched ROM by Asure based on version above, enables selection between white/black label
    "b91881322f262316db2c43e01bb8ee871955a2c5552f50b80bf2f405fdbbe72e": ( True, False, True, ((0x00000, 0x400000, "ddp3_rg/ddp3_p1_dual.bin"),)),
    # unknown version from oneleaf86's ROM collection, doesn't contain AMB string:
    "ac18adde4dee77652c15df505d1e79fec09b7a50999bec78c9737fd0ad3531c3": ( True, False, True, ((0x00000, 0x400000, "ddp3_rg/ddp3_p1_bl.bin"),)),
    "7c137d77cab1a1f15439caa8f7a0c41c42ab79b468a764b4af1e4b89d95aae20": ( False, False, False, ((0x00000, 0x400000, "ddp3_rg/ddp3_a1.bin"), (0x400000, 0x400000, "ddp3_rg/ddp3_a2.bin"))),
    "5aa661f836066576588b255df93c9235e561669756643aa51575d2b74e5c4223": ( False, False, False, ((0x00000, 0x400000, "ddp3_rg/ddp3_a3.bin"), (0x400000, 0x400000, "ddp3_rg/ddp3_a4.bin"))),
    "0f07f3a763316e2c044b6cc5c96e302679e5179de965af1d890196a5683caf9b": ( False, False, False, ((0x00000, 0x400000, "ddp3_rg/ddp3_b1.bin"), (0x400000, 0x400000, "ddp3_rg/ddp3_b2.bin"))),
    "7a54fa9832c3d66b8f6da847cdde19e5c515afc16fae4e0a78be5229959b7054": ( False, False, False, ((0x00000, 0x400000, "ddp3_rg/ddp3_t1.bin"), (0x400000, 0x400000, "ddp3_rg/ddp3_t2.bin"))),
    "456146197799e0786032a6b3a8b70d7edfc0a2e51edd06da82cc71ca266eeaa7": ( False, False, False, ((0x00000, 0x400000, "ddp3_rg/ddp3_m1.bin"),)),

    # Espgaluda
    "ae794f0537ebef80b02c9658aaee1bf39b987816574b3d01063c91bdd682437c": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_p1.bin"),)),
    "37c0f39af1b324bf96f17e8584faddc272f3a27ab735e4fc8ad9cdcdcb6dea9a": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_a1.bin"), (0x400000, 0x400000, "espgal_rg/espgal_a2.bin"))),
    "c8b23f1b7251cb8025d9608804066ea1ce4bdf010a61234f982ba32f0fae4480": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_a3.bin"), (0x400000, 0x400000, "espgal_rg/espgal_a4.bin"))),
    "02344445327b9920f63853067ae2bb36fc1ce155baacc001b44531879da9a708": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_b1.bin"), (0x400000, 0x400000, "espgal_rg/espgal_b2.bin"))),
    "71189faec31ed2c12ae7ebe4f99e634381cd865c4c807f7a12a2f4fa3ad1e771": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_t1.bin"), (0x400000, 0x400000, "espgal_rg/espgal_t2.bin"))),
    "dc5851a7850c17c26d613ac807aa639adaa1c5bf16cb3d9e232cc4c7eee0ce70": ( False, False, False, ((0x00000, 0x400000, "espgal_rg/espgal_m1.bin"),)),

    # Ketsui
    # Program rom from Mame bootleg romset
    "d901e6def971df10574e23622c677b68eeece250e1db3908b42a12342689fb26": ( False, True, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_p1.bin"),)),
    # Contains "arranged" Trap version in second bank ( http://daifukkat.su/hacks/ketarr/ )
    "10def8ed8b90de2ed90def22e0eaa47534bd3bf7d03c14ba1c903e618d93b310": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_p1_trap.bin"),)),
    "59b3252abc7895307d30b4e87d799dfaa0b6b67b6f288ea049b028622d1818dc": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_a1.bin"), (0x400000, 0x400000, "ketsui_rg/ketsui_a2.bin"))),
    "66d4fb0e653335ae38021c12a668ec66f43fca06b50a2654568b818711af55ad": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_a3.bin"), (0x400000, 0x400000, "ketsui_rg/ketsui_a4.bin"))),
    "636c685fe3c2b9b17edbd285411e43367db49cc04f73059517670830bb9ac871": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_b1.bin"), (0x400000, 0x400000, "ketsui_rg/ketsui_b2.bin"))),
    "5d7370c7cda22401d32c0406b658971cd455d8241ac3d627cfaa3be62df3c200": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_t1.bin"), (0x400000, 0x400000, "ketsui_rg/ketsui_t2.bin"))),
    "33a3899f0b8462d3013be47d471aba321fdf27ea3267a734e2bdc1cabcd7dfd0": ( False, False, False, ((0x00000, 0x400000, "ketsui_rg/ketsui_m1.bin"),)),

    # BIOS
    # PGM BIOS V1
    "16ac453200130288c76d92cf3cc677f5ae8a16d11e45277ea0d1210d6b3f7d9b": ( False, False, False, ((0x00000, 0x020000, "bios_rg/bios_v1.bin"),)),
    # PGM BIOS V2
    "289939053063e5492368ab57316c9dee2d5a52ad445e97d642a8e0060dd9a4ed": ( False, False, False, ((0x00000, 0x020000, "bios_rg/bios_v2.bin"),)),
    # "The Gladiator" stand alone PCB
    "30960c4af2db26101cf684f8fa215178d89d275a4f447c37d39f1115ad4140d1": ( False, False, False, ((0x00000, 0x020000, "bios_rg/bios_gladpcb.bin"),)),
}

# KoV SH decryption table from MAME driver
kovsh_tab = [
	0xe7, 0x06, 0xa3, 0x70, 0xf2, 0x58, 0xe6, 0x59, 0xe4, 0xcf, 0xc2, 0x79, 0x1d, 0xe3, 0x71, 0x0e,
	0xb6, 0x90, 0x9a, 0x2a, 0x8c, 0x41, 0xf7, 0x82, 0x9b, 0xef, 0x99, 0x0c, 0xfa, 0x2f, 0xf1, 0xfe,
	0x8f, 0x70, 0xf4, 0xc1, 0xb5, 0x3d, 0x7c, 0x60, 0x4c, 0x09, 0xf4, 0x2e, 0x7c, 0x87, 0x63, 0x5f,
	0xce, 0x99, 0x84, 0x95, 0x06, 0x9a, 0x20, 0x23, 0x5a, 0xb9, 0x52, 0x95, 0x48, 0x2c, 0x84, 0x60,
	0x69, 0xe3, 0x93, 0x49, 0xb9, 0xd6, 0xbb, 0xd6, 0x9e, 0xdc, 0x96, 0x12, 0xfa, 0x60, 0xda, 0x5f,
	0x55, 0x5d, 0x5b, 0x20, 0x07, 0x1e, 0x97, 0x42, 0x77, 0xea, 0x1d, 0xe0, 0x70, 0xfb, 0x6a, 0x00,
	0x77, 0x9a, 0xef, 0x1b, 0xe0, 0xf9, 0x0d, 0xc1, 0x2e, 0x2f, 0xef, 0x25, 0x29, 0xe5, 0xd8, 0x2c,
	0xaf, 0x01, 0xd9, 0x6c, 0x31, 0xce, 0x5c, 0xea, 0xab, 0x1c, 0x92, 0x16, 0x61, 0xbc, 0xe4, 0x7c,
	0x5a, 0x76, 0xe9, 0x92, 0x39, 0x5b, 0x97, 0x60, 0xea, 0x57, 0x83, 0x9c, 0x92, 0x29, 0xa7, 0x12,
	0xa9, 0x71, 0x7a, 0xf9, 0x07, 0x68, 0xa7, 0x45, 0x88, 0x10, 0x81, 0x12, 0x2c, 0x67, 0x4d, 0x55,
	0x33, 0xf0, 0xfa, 0xd7, 0x1d, 0x4d, 0x0e, 0x63, 0x03, 0x34, 0x65, 0xe2, 0x76, 0x0f, 0x98, 0xa9,
	0x5f, 0x9a, 0xd3, 0xca, 0xdd, 0xc1, 0x5b, 0x3d, 0x4d, 0xf8, 0x40, 0x08, 0xdc, 0x05, 0x38, 0x00,
	0xcb, 0x24, 0x02, 0xff, 0x39, 0xe2, 0x9e, 0x04, 0x9a, 0x08, 0x63, 0xc8, 0x2b, 0x5a, 0x34, 0x06,
	0x62, 0xc1, 0xbb, 0x8a, 0xd0, 0x54, 0x4c, 0x43, 0x21, 0x4e, 0x4c, 0x99, 0x80, 0xc2, 0x3d, 0xce,
	0x2a, 0x7b, 0x09, 0x62, 0x1a, 0x91, 0x9b, 0xc3, 0x41, 0x24, 0xa0, 0xfd, 0xb5, 0x67, 0x93, 0x07,
	0xa7, 0xb8, 0x85, 0x8a, 0xa1, 0x1e, 0x4f, 0xb6, 0x75, 0x38, 0x65, 0x8a, 0xf9, 0x7c, 0x00, 0xa0,
]

# KoV SH decryption function from MAME driver
def decrypt_block(data):
    src = bytearray (data)

    # Only the first 2MB contain valid data, the rest is empty
    for i in range(0x100000):
        x, = struct.unpack_from("<H", src, i * 2)
        if ((i & 0x040080) != 0x000080): x ^= 0x0001
        if ((i & 0x004008) == 0x004008 and (i & 0x180000) != 0x000000): x ^= 0x0002
        if ((i & 0x000030) == 0x000010): x ^= 0x0004
        if ((i & 0x000242) != 0x000042): x ^= 0x0008
        if ((i & 0x008100) == 0x008000): x ^= 0x0010
        if ((i & 0x002004) != 0x000004): x ^= 0x0020
        if ((i & 0x011800) != 0x010000): x ^= 0x0040
        if ((i & 0x000820) == 0x000820): x ^= 0x0080
        x ^= kovsh_tab[i & 0xff] << 8
        struct.pack_into("<H", src, i * 2, x)

    return src

# identify a data block and generate the output files
def generate(data, path, output):
    global bios

    m = hashlib.sha256()
    m.update(data)
    digest = m.hexdigest()
    try:
        decrypt,swap_banks,quickboot,parts = rules[digest]
        if decrypt:
            data = decrypt_block(data)
        if swap_banks:
            s = len(data)//2
            data = data[s:s+s]+data[0:s]
        if quickboot and bios != None:
            tmp = bytearray([0xFF for x in range(0x400000)])
            tmp[0:len(bios)] = bios
            tmp[0x100000:0x300000] = data
            data = tmp
        for start, size, name in parts:
            if quickboot and bios != None:
                base,ext = os.path.splitext(name)
                name = base + "_qb" + ext
            filepath = os.path.join(output, name)
            dirname = os.path.dirname(filepath)
            if not os.path.exists(dirname):
                print ("creating %s" % dirname)
                os.makedirs(dirname)
            print("writing %s ..." % name)
            with open(name, "wb") as f:
                f.write(data[start:start+size])
    except KeyError:
        # print("ignoring file %s [%s]" % (path, digest))
        pass

# scan the path get data to convert
def scan(path, output):
    if os.path.isdir(path):
        files = os.listdir(path)
        for name in files:
            if name[0] != '.':
                scan(os.path.join(path, name), output)
    elif os.path.isfile(path):
        if zipfile.is_zipfile(path):
            archive = zipfile.ZipFile(path, "r")
            infolist = archive.infolist()
            for info in infolist:
                if info.file_size > 0:
                    d = archive.read(info)
                    generate(d, os.path.join(path, info.filename), output)
            archive.close()
        else:
            with open(path, "rb") as f:
                d = f.read()
                generate(d, path, output)

# parse arguments and run converter
def main():
    global bios

    parser = argparse.ArgumentParser(description='Generate ROMs for ROMGRAVE PCB cartridge.')
    parser.add_argument('files', metavar='file', type=str, nargs='+',
                        help='a list of files, zip-files or directories to convert')
    parser.add_argument('-o', '--output', dest='output',
                        default=os.getcwd(),
                        help='output directory')
    parser.add_argument('-b', '--bios', dest='bios', type=str,
                        help='BIOS to use for a quickboot variant')

    args = parser.parse_args()
    if args.bios:
        print("Loading BIOS %s" % args.bios)
        with open(args.bios, "rb") as f:
            bios = f.read()

    for f in args.files:
        expanded_files = glob.glob(f)
        for ef in expanded_files:
            scan(ef, args.output)

# validate that we've got Python 3
if sys.version_info[0] < 3:
    raise Exception("Must be using Python 3")

# execute only if run as a script
if __name__ == "__main__":
    main()
